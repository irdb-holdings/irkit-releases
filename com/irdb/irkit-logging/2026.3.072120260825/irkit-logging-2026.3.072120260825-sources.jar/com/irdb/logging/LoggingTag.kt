package com.irdb.logging

/**
 * The complete, closed taxonomy of logging tags used by the IRKit SDK family
 * (IRKIT, IRKit-UI, Analytics, and any future library). No string tags are
 * permitted anywhere in the codebase — every log call must reference one of
 * these enum values.
 *
 * Adding a new tag: declare a new enum entry below with a stable [tagString]
 * (used as the logcat suffix after the `IRKIT_` prefix) and an explicit
 * [defaultEnabled].
 *
 * **All production tags default to `false`.** Library logs stay silent until
 * the host app opts in by calling [IRKITLog.enable], [IRKITLog.enableOnly],
 * or [IRKITLog.enableAll] from its `Application.onCreate()` — typically
 * inspecting only one or two tags at a time keeps logcat readable.
 * [IRKITLog.error] always emits regardless of this default.
 *
 * This type is publicly visible to clients of the IRKit AARs so they can
 * runtime-tune logging output via the [IRKITLog] APIs from their host app.
 */
enum class LoggingTag(
    val tagString: String,
    val defaultEnabled: Boolean = false,
) {
    /** REST/HTTP calls into the IRKit backend — request/response wire activity. */
    REST_API("REST_API", defaultEnabled = false),

    /** Image recognition session lifecycle, match results, scan progress. */
    RECOGNITION("RECOGNITION", defaultEnabled = false),

    /** IRCODE lookup and field-resolution payload dumps. */
    IRCODE_RESOLUTION("IRCODE_RESOLUTION", defaultEnabled = false),

    /** Gson adapter chatter and JSON encode/decode tracing. */
    JSON_SERDE("JSON_SERDE", defaultEnabled = false),

    /** Camera preview, resolution binding, and device-tier capability detection. */
    CAMERA("CAMERA", defaultEnabled = false),

    /** ONNX segmentation pipeline — init, inference, model loading. */
    SEGMENTATION("SEGMENTATION", defaultEnabled = false),

    /** Process / activity / lens session lifecycle. */
    LIFECYCLE("LIFECYCLE", defaultEnabled = false),

    /** Bitmap utilities, OCR, color/text extraction, image-side processing. */
    IMAGE_PROCESSING("IMAGE_PROCESSING", defaultEnabled = false),

    /** Analytics module internals — queue, flush, event flow, param validation. */
    // tagString shortened to keep `IRKIT_<tagString>` within Android's 23-char convention.
    ANALYTICS_INTERNAL("ANALYTICS_INT", defaultEnabled = false),

    /** Compose UI flow — dialogs, sheets, result cards, WebView, mode toggles. */
    UI("UI", defaultEnabled = false),

    OFFLINE_MODE("OFFLINE_MODE", defaultEnabled = false),
}
