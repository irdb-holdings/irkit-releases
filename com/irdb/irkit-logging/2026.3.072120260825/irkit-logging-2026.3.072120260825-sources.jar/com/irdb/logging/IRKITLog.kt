package com.irdb.logging

import android.util.Log
import java.util.concurrent.ConcurrentHashMap

/**
 * Centralized logging singleton for the IRKit SDK family. Wraps
 * [android.util.Log] with:
 *
 *  - **Enum-driven tags** — only [LoggingTag] values are accepted; no string
 *    tags anywhere in the codebase.
 *  - **Hybrid filtering** — each tag has a compile-time
 *    [LoggingTag.defaultEnabled] default; runtime overrides set via
 *    [enable] / [disable] / [enableOnly] / [enableAll] / [disableAll] take
 *    precedence; [resetToDefaults] clears all overrides.
 *  - **Release-build suppression** — every level except [error] is gated by
 *    [init]; [error] always logs regardless of state.
 *  - **`IRKIT_<TAG>` logcat prefix** — all messages share a single greppable
 *    family prefix.
 *
 * **Initialization.** Call [init] from your host app's `Application.onCreate()`
 * passing `BuildConfig.DEBUG`. Doing it from the app (not the library) is
 * essential — `BuildConfig.DEBUG` inside an AAR reflects how the library was
 * built, not the consuming app. If [init] is never called, the singleton
 * stays in the safest mode: non-error logs are suppressed but [error] still
 * emits.
 *
 * **Thread safety.** [ConcurrentHashMap] guards override state and `isDebug`
 * is `@Volatile`, so per-tag operations ([enable], [disable], [isEnabled],
 * [error], and the level helpers) are individually thread-safe. The bulk
 * operations ([enableOnly] / [enableAll] / [disableAll]) apply per-tag and are
 * **not atomic as a group** — a concurrent reader may observe a half-applied
 * state. This API is intended to be configured once during app startup, so that
 * is not a concern in practice.
 *
 * This type is publicly visible to clients of the IRKit AARs so a host app
 * can runtime-tune library logging.
 */
object IRKITLog {

    @Volatile
    private var isDebug: Boolean = false

    private val overrides = ConcurrentHashMap<LoggingTag, Boolean>()

    /**
     * Indirection seam — production uses [AndroidLogSink], tests swap in a
     * fake. Internal-only so it doesn't escape the AAR boundary.
     */
    internal var sink: LogSink = AndroidLogSink

    /**
     * Configure debug mode. Pass the host app's `BuildConfig.DEBUG`. When
     * `false`, all levels except [error] become no-ops regardless of tag
     * enable state.
     */
    fun init(isDebug: Boolean) {
        this.isDebug = isDebug
    }

    /**
     * Returns the effective enabled state for [tag]: a runtime override if
     * one exists, otherwise the enum's [LoggingTag.defaultEnabled].
     */
    fun isEnabled(tag: LoggingTag): Boolean = resolveEnabled(overrides[tag], tag.defaultEnabled)

    /** Override [tag] to enabled. Survives until [resetToDefaults]. */
    fun enable(tag: LoggingTag) {
        overrides[tag] = true
    }

    /** Override [tag] to disabled. [error] is unaffected. */
    fun disable(tag: LoggingTag) {
        overrides[tag] = false
    }

    /**
     * Override every [LoggingTag] value: the supplied [tags] become enabled,
     * all others disabled. Convenient for "show me only X right now."
     */
    fun enableOnly(vararg tags: LoggingTag) {
        val set = tags.toSet()
        LoggingTag.values().forEach { overrides[it] = it in set }
    }

    /** Override every [LoggingTag] value to enabled. */
    fun enableAll() {
        LoggingTag.values().forEach { overrides[it] = true }
    }

    /** Override every [LoggingTag] value to disabled. [error] is unaffected. */
    fun disableAll() {
        LoggingTag.values().forEach { overrides[it] = false }
    }

    /** Clear every runtime override; each tag falls back to its enum default. */
    fun resetToDefaults() {
        overrides.clear()
    }

    /** Logs at VERBOSE level; suppressed in release builds and when [tag] is disabled. */
    fun verbose(tag: LoggingTag, message: String, throwable: Throwable? = null) {
        emit(Log.VERBOSE, tag, message, throwable)
    }

    /** Logs at DEBUG level; suppressed in release builds and when [tag] is disabled. */
    fun debug(tag: LoggingTag, message: String, throwable: Throwable? = null) {
        emit(Log.DEBUG, tag, message, throwable)
    }

    /** Logs at INFO level; suppressed in release builds and when [tag] is disabled. */
    fun info(tag: LoggingTag, message: String, throwable: Throwable? = null) {
        emit(Log.INFO, tag, message, throwable)
    }

    /** Logs at WARN level; suppressed in release builds and when [tag] is disabled. */
    fun warn(tag: LoggingTag, message: String, throwable: Throwable? = null) {
        emit(Log.WARN, tag, message, throwable)
    }

    /**
     * Logs at ERROR level. Always emits — never gated by [init] state or
     * tag enable state. Use for conditions that demand attention regardless
     * of release/debug.
     */
    fun error(tag: LoggingTag, message: String, throwable: Throwable? = null) {
        sink.log(Log.ERROR, formatTag(tag), message, throwable)
    }

    private fun emit(priority: Int, tag: LoggingTag, message: String, throwable: Throwable?) {
        if (!isDebug) return
        if (!isEnabled(tag)) return
        sink.log(priority, formatTag(tag), message, throwable)
    }

    private fun formatTag(tag: LoggingTag): String = "IRKIT_${tag.tagString}"

    /**
     * Resolves a tag's effective enabled state: a runtime [override] wins when
     * present, otherwise the enum's [default]. Internal seam so tests can cover
     * the `default = true` branch directly — no production tag defaults to true,
     * so it is otherwise unreachable from a real [LoggingTag].
     */
    internal fun resolveEnabled(override: Boolean?, default: Boolean): Boolean = override ?: default
}

/**
 * Minimal indirection over [android.util.Log]. Internal so tests in this
 * module can substitute a recording fake without exposing the seam to
 * downstream AAR consumers.
 */
internal interface LogSink {
    fun log(priority: Int, tag: String, message: String, throwable: Throwable?)
}

internal object AndroidLogSink : LogSink {
    override fun log(priority: Int, tag: String, message: String, throwable: Throwable?) {
        when (priority) {
            Log.VERBOSE -> if (throwable != null) Log.v(tag, message, throwable) else Log.v(tag, message)
            Log.DEBUG -> if (throwable != null) Log.d(tag, message, throwable) else Log.d(tag, message)
            Log.INFO -> if (throwable != null) Log.i(tag, message, throwable) else Log.i(tag, message)
            Log.WARN -> if (throwable != null) Log.w(tag, message, throwable) else Log.w(tag, message)
            Log.ERROR -> if (throwable != null) Log.e(tag, message, throwable) else Log.e(tag, message)
        }
    }
}
